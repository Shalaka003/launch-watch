# Launch Watch

A feature concept for Profound: an agent template that tells a marketing team whether AI knows about their new launch, and what to fix when it doesn't.

I built this as a work sample for Profound's Member of Technical Staff, Product Operations role. It has two parts:

- **A clickable prototype:** [`index.html`](index.html)
- **A 10-slide deck** on what it is and how I'd ship it: [`launch-watch-deck.pdf`](launch-watch-deck.pdf)

## The problem

A launch is when a brand most needs AI to get it right, and when AI is most likely to get it wrong.

- **AI hasn't seen it.** AI crawlers haven't visited the new page yet, so answers can't mention it.
- **AI gets it wrong.** Answers still show the old name, price or features from older pages.
- **Teams check by hand.** Marketers type prompts into ChatGPT one at a time to find out.

## The feature

Every day for 30 days, Launch Watch runs four checks in order. Each one uses a part of Profound that already exists.

| Check | Question | Built on |
|---|---|---|
| 1. Crawled | Have AI crawlers visited the launch page? | Agent Analytics |
| 2. Cited | Do AI answers link to the launch page? | Citation Analytics |
| 3. Mentioned | Does the launch show up for the prompts that matter? | Answer Engine Insights |
| 4. Correct | Do those answers match the launch facts? | FactCheck |

Profound's Prompt Analysis post (12 Nov 2026) tells customers to track a launch by hand. Launch Watch turns that advice into a template.

## How it works

1. **Name the launch:** the page, the date, the regions, and 3 to 5 facts that must be right (for example the name, price and who it's for).
2. **The agent picks 20 prompts** people really ask, from research to purchase, using Prompt Analysis.
3. **Every day for 30 days**, it runs the four checks across ChatGPT, Perplexity, Google AI Overviews, Gemini and Claude.
4. **Every week**, it sends a short report and stages fixes, most-asked prompts first. Nothing goes live until a person approves.

## The prototype

One HTML file, with no build step and no dependencies apart from the Inter font.

- **Set up:** the launch name, page, facts, platforms and the 20 prompts.
- **Report:** play or scrub through the 30 days and watch the four checks fill up. See what needs attention, such as a wrong price or a prompt where the launch is missing. Open the drafted fix, approve it, and see which AI crawlers have visited the page and what each prompt returns.

**To run it:** open `index.html` in a browser. To share a live link, turn on GitHub Pages under Settings → Pages, deploying from the `main` branch.

## How I'd ship it

| Week | Work | Move on when |
|---|---|---|
| 1. Spec | One-page spec with engineering; agree how "correct" is judged | Engineering signs off the spec and the cost |
| 2. Test | Run it for 3 customers with launches coming up; compare to a check done by hand | Its findings match the check by hand |
| 3. Prepare | Release note, help page, demo script; train sales and customer success | Sales can demo it without help |
| 4. Launch | Add to the template library; share in the company update; flag accounts with launches coming | Customers outside the test group use it |

**How I'd know it's working:**

- **Adoption:** the share of active accounts that start a Launch Watch within 60 days of release.
- **Usage:** fixes approved. If customers don't approve the fixes it stages, the fixes aren't good enough yet.
- **Outcome:** days from launch until AI answers get it right. This should drop launch after launch.

## Open questions for engineering

- **Reusing runs.** AI gives a different answer every time, so Profound already asks each prompt many times a day. Can Launch Watch reuse those runs, and count a prompt as mentioned when the launch shows up in most of them?
- **Judging "correct".** Start with a model check, and have a person review anything it flags.
- **Missing data.** The crawl step needs Agent Analytics connected. If it isn't, skip that step and show how to connect it.

## Note

This is an independent concept and isn't affiliated with or endorsed by Profound. Product names belong to Profound and are used only to show how the feature would fit. Wrenfield is the sample brand from Profound's homepage, and all data in the prototype is made up.
